<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-danger">
                <div class="panel-heading">Error Page</div>

                <div class="panel-body">
                    <h1><span class="label label-danger"> <?php echo e($code); ?> - <?php echo e($title); ?> </span></h1>
                    <hr>
                    <h4 class="text-danger"><?php echo e($message); ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>